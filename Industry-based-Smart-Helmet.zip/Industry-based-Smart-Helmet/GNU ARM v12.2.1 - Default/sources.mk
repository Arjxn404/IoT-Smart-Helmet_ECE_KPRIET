################################################################################
# Automatically-generated file. Do not edit!
################################################################################

S79_SRCS := 
OBJ_SRCS := 
S_SRCS := 
ASM_SRCS := 
C_SRCS := 
S79_UPPER_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
EXECUTABLES := 
OBJS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
. \
autogen \
simplicity_sdk_2025.6.3/platform/CMSIS/RTOS2/Source \
simplicity_sdk_2025.6.3/platform/common/src \
simplicity_sdk_2025.6.3/platform/service/mem_pool/src \
simplicity_sdk_2025.6.3/platform/service/sl_main/src/rtos \
simplicity_sdk_2025.6.3/platform/service/sl_main/src \
simplicity_sdk_2025.6.3/util/third_party/freertos/cmsis/Source \
simplicity_sdk_2025.6.3/util/third_party/freertos/kernel \
simplicity_sdk_2025.6.3/util/third_party/freertos/kernel/portable/GCC/ARM_CM4F \
simplicity_sdk_2025.6.3/util/third_party/freertos/kernel/portable/MemMang \
wiseconnect3_sdk_3.5.2/components/board/silabs/src \
wiseconnect3_sdk_3.5.2/components/common/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/chip/src/iPMU_prog/iPMU_dotc \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/chip/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/common/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/core/config/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/drivers/cmsis_driver \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/drivers/peripheral_drivers/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/drivers/service/clock_manager/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/drivers/systemlevel/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/mcu/drivers/unified_api/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/ahb_interface/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/asynchronous_socket/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/errno/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/firmware_upgrade \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/host_mcu/si91x \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/icmp \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/memory \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/sl_net/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/socket/src \
wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/src \
wiseconnect3_sdk_3.5.2/components/protocol/wifi/si91x \
wiseconnect3_sdk_3.5.2/components/protocol/wifi/src \
wiseconnect3_sdk_3.5.2/components/service/bsd_socket/si91x_socket \
wiseconnect3_sdk_3.5.2/components/service/network_manager/src \
wiseconnect3_sdk_3.5.2/components/service/sl_http_server/src \
wiseconnect3_sdk_3.5.2/components/sli_si91x_wifi_event_handler/src \
wiseconnect3_sdk_3.5.2/components/sli_wifi_command_engine/src \
wiseconnect3_sdk_3.5.2/third_party/json_parser/src \

