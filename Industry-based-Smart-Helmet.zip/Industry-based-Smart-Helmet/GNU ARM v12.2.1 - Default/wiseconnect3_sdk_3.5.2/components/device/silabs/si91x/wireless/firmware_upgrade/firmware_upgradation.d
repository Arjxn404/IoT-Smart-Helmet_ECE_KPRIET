wiseconnect3_sdk_3.5.2/components/device/silabs/si91x/wireless/firmware_upgrade/firmware_upgradation.o: \
 C:/Users/iot_e/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/components/device/silabs/si91x/wireless/firmware_upgrade/firmware_upgradation.c \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_utility.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_types.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\socket.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\uio.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\sys.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet_in.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet6_in6.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\select.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_constants.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\errno\inc\errno.h \
 c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_string.h
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_utility.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_types.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\socket.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\uio.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\sys.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet_in.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet6_in6.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\select.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_constants.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\errno\inc\errno.h:
c:\users\iot_e\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_string.h:
